var tela = 1

var y = 150;
var fundo;
controle = false

function setup () {
  createCanvas (600,400);
  fundo = loadImage('fundo.png');
  instrucoes = loadImage('instrucoes.jpg');
  creditos = loadImage('creditos.jpg');
}

function draw() {
  //tela do menu...
  if(tela ===1){
    background(fundo);
    textSize(25);
    textAlign(CENTER);
    
    noStroke();
    fill(34,139,34);
    rect(110,y,180,30);
    
    fill(800);
    text('JOGAR',200,173);
    text('INSTRUÇÕES',200,223);
    text('CRÉDITOS', 200,273);
    
   
    if(keyIsPressed ===false) {
      controle = false; }
    if (controle ===false){
      if(keyIsDown (UP_ARROW) && (y <= 250 && y>150)){
       y -= 50;
      controle = true;
      }
    if(keyIsDown(ENTER) && y === 150) {
     tela = 2;
      controle = true;
    }  
      else if (keyIsDown (ENTER) && y === 200) {
        tela = 3;
        controle = true;
      }
      else if (keyIsDown (ENTER) && y === 250) {
        tela = 4 
        controle = true
      }
      
      if ( keyIsDown (DOWN_ARROW) && (y < 250 && y >= 150)) {
        y += 50
        controle = true
      }
    }
  }

  //EM JOGO...
  else if (tela === 2){
    background (fundo);
    textSize (20)
    textAlign (CENTER)
    
    fill (34,139,34);
    text ('Aperta Esc para voltar!', 180,380);
    fill (34,139,34);
    rect (80,190,230,40);
    fill (255,255,255);
    text ('JOGANDO...', 200,220);
    
    if (keyIsDown (ESCAPE)) {
      tela = 1
    }
  }
  
  //Instruções...
  else if (tela === 3) {
    background (creditos);
    textSize(14)
    
    if(keyIsDown(ESCAPE)){
      tela = 1
    }
  }
  
  // Créditos...
  else if (tela === 4) {
    background (instrucoes)
  
    if (keyIsDown (ESCAPE)) { tela =1}
  }
}